package DBControll;

import java.util.List;

import org.MyDataBase.onetomany.Address;

public interface AddressDBInterface {

    public void create(Address address);

    public Address getAddressById(int id);

    public List<Address> ListAddress();

    public Address updateAddress(Address address);

    void deleteAddressByCustomerId(int id);
    void deleteAddressByArenaId(int id);


}