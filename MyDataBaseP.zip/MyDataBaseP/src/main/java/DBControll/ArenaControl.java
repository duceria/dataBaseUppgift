package DBControll;

import org.MyDataBase.onetomany.Address;
import org.MyDataBase.onetomany.Arena;
import org.MyDataBase.onetomany.Concert;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;
import java.util.Scanner;

public class ArenaControl implements ArenaDBInterface{
    @Override
    public void create(Arena arena) {
            SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
            Session session = sessionFactory.openSession();
            session.beginTransaction();
            session.persist(arena);
            session.getTransaction().commit();
            session.close();
            System.out.println("arena name and address saved successfully!");
    }

    @Override
    public Arena getArenaById(int id) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Arena arena=session.get(Arena.class,id);
        session.getTransaction().commit();
        session.close();
        return arena;
    }

    @Override
    public List<Arena> ListArena() {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        List<Arena> arenas = session.createQuery("FROM Arena", Arena.class).getResultList();
        return arenas;
    }

    @Override
    public Arena updateArena(Arena arena) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.update(arena);
        session.getTransaction().commit();
        session.close();
        System.out.println("Arena info saved successfully!");
        return arena;
    }

    @Override
    public void deleteArenaById(int id) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Arena arena = session.get(Arena.class, id);
        session.delete(arena);
        session.getTransaction().commit();
        session.getTransaction().rollback();
        session.close();
    }
    public int getArenaIdByAddressId(int addressId) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Integer arenaId = session.createQuery("SELECT c.id FROM Arena c WHERE c.address.id = :addressId", Integer.class)
                .setParameter("addressId", addressId)
                .uniqueResult();
        session.getTransaction().commit();
        session.close();
        return arenaId;
    }

    public int getArenaIdByConcertId(int concertId) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        Integer arenaId = session.createQuery("SELECT a.id FROM Arena a JOIN a.concert c WHERE c.id = :concertId", Integer.class)
                .setParameter("concertId", concertId)
                .uniqueResult();

        session.getTransaction().commit();
        session.close();
        return arenaId;
    }

    }


