package DBControll;



import java.util.List;
import org.MyDataBase.onetomany.Concert;

public interface ConsertDBInterface {

    public void create(Concert consert);

    public Concert getConsertById(int id);

    public List<Concert> ListConsert();

    public Concert updateConserta(Concert consert);

    void deleteConsertById(int id);

}