package DBControll;

import org.MyDataBase.onetomany.Address;
import org.MyDataBase.onetomany.Arena;
import org.MyDataBase.onetomany.Concert;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;
import java.util.Scanner;

import static java.lang.System.*;

public class ConcertControl implements ConsertDBInterface{
    @Override
    public void create(Concert concert) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.persist(concert);
        session.getTransaction().commit();
        session.close();
        System.out.println("concert name and address saved successfully!");
    }

    @Override
    public Concert getConsertById(int id) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Concert concert=session.get(Concert.class,id);
        session.getTransaction().commit();
        session.close();
        return concert;
    }

    @Override
    public List<Concert> ListConsert() {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        List<Concert> concerts = session.createQuery("FROM Concert", Concert.class).getResultList();
        return concerts;

    }

    @Override
    public Concert updateConserta(Concert concert) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.update(concert);
        session.getTransaction().commit();
        session.close();
        System.out.println("concert info saved successfully!");
        return concert;

    }

    @Override
    public void deleteConsertById(int id) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Concert concert = session.get(Concert.class, id);
        session.delete(concert);
        session.getTransaction().commit();
      //session.getTransaction().rollback();
        session.close();

    }


    }

