package DBControll;
import org.MyDataBase.onetomany.Arena;


import java.util.List;

public interface ArenaDBInterface {

    public void create(Arena arena);

    public Arena getArenaById(int id);

    public List<Arena> ListArena();

    public Arena updateArena(Arena arena);

    void deleteArenaById(int id);

}