package DBControll;

import org.MyDataBase.onetomany.Address;
import org.MyDataBase.onetomany.Concert;
import org.MyDataBase.onetomany.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class CustomrtControl implements CustomerDBInterface{
    @Override
    public void create(Customer customer) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.persist(customer);
        session.getTransaction().commit();
        session.close();
        System.out.println("customer name and address saved successfully!");
    }

    @Override
    public Customer getCustomerById(int id) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Customer customer=session.get(Customer.class,id);
        session.getTransaction().commit();
        session.close();
        return customer;
    }

    @Override
    public List<Customer> ListCustomer() {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        List<Customer> customers = session.createQuery("FROM Customer", Customer.class).getResultList();
        return customers;    }

    @Override
    public Customer updateCustomer(Customer customer) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.update(customer);
        session.getTransaction().commit();
        session.close();
        System.out.println("concert info saved successfully!");
        return customer;
    }

    @Override
    public void deleteCustomerById(int id) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Customer customer = session.get(Customer.class, id);
        session.delete(customer);
        session.getTransaction().commit();
        //session.getTransaction().rollback();
        session.close();
    }
    public int getCustomerIdByAddressId(int addressId) {
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Integer customerId = session.createQuery("SELECT c.id FROM Customer c WHERE c.address.id = :addressId", Integer.class)
                .setParameter("addressId", addressId)
                .uniqueResult();
        session.getTransaction().commit();
        session.close();
        return customerId;
    }

    }


