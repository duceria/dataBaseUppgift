package org.MyDataBase;
import DBControll.AddressControl;
import DBControll.ArenaControl;
import DBControll.ConcertControl;
import DBControll.CustomrtControl;
import org.MyDataBase.onetomany.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
//        Customer customer=new Customer();
//        Address address = new Address();
//        Arena arena=new Arena();
//        Concert concert=new Concert();
//        Wc wc=new Wc();
//
//        address.setCity("Umeå");
//        address.setStreet("Älvans Väg 4");
//        address.setHouseNumber(1104);
//        address.setPostalCode(90750);
//        address.setCustomer(customer);
//
//        customer.setFirstName("Tarek");
//        customer.setLastName("Husein");
//        customer.setBirthDate("14-05-2024");
//        customer.setPhoneNumber("07589644");
//        customer.setAddress(address);


        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        Customer customer=new Customer();
        session.persist(customer);

        customer=session.get(Customer.class,1);

        customer.setFirstName("Urban");
        session.update(customer);


        session.getTransaction().commit();
        session.close();
//        Scanner scanner = new Scanner(System.in);
//        boolean isLoggedIn = false;
//        String password = "mittlösenord";

//        while (true) {
//            System.out.println("Välj ett alternativ:");
//            System.out.println("1. Logga in");
//            System.out.println("2. Alternativ 2");
//            System.out.println("3. Alternativ 3");
//            System.out.println("4. Alternativ 4");
//            System.out.println("0. Avsluta");
//            int val = scanner.nextInt();
//            switch (val) {
//                case 0:
//                    System.out.println("Avslutar programmet...");
//                    System.exit(0);
//                    break;
//                case 1:
//                    if (!isLoggedIn) {
//                        System.out.println("Ange lösenord:");
//                        String inputPassword = scanner.next();
//                        if (inputPassword.equals(password)) {
//                            System.out.println("Inloggning lyckades!");
//                            isLoggedIn = true;
//                        } else {
//                            System.out.println("Fel lösenord. Försök igen.");
//                        }
//                    } else {
//                        System.out.println("Du är redan inloggad.");
//                    }
//                    break;
//                case 2:
//                    System.out.println("Boka biljetter.");
//                    break;
//                case 3:
//                    System.out.println("Lista biljetter.");
//                    break;
//                case 4:
//                    System.out.println("Se kundvagnen.");
//                    break;
//                default:
//                    System.out.println("Ogiltigt val. Försök igen.");
//                    break;
//            }

//
//        City city = new City();
//        city.setName("Umeå");
//
//        ConcertControl concertControl=new ConcertControl();
//
//        Concert concert=new Concert("tttt","22-04-2024",200,18);
//        concertControl.create(concert);
//        Concert concert2=new Concert();
//        concert2=concertControl.getConsertById(1);
//        System.out.println(concert2);
//        concert2.setTicketPrice(5000);
//        concertControl.updateConserta(concert2);
//        System.out.println(concertControl.getConsertById(1));
        Address address=new Address("älvans",45,6758,"umeå");
//        Customer customer1=new Customer("Tarek","Makdesi","25-04-2024","8545646",address);
        AddressControl addressControl=new AddressControl();
//        CustomrtControl  customrtControl=new CustomrtControl();
//        customrtControl.create(customer1);
//       Arena arena=new Arena("umeå",1,address);
//    //    addressControl.deleteAddressById(2);
        ArenaControl arenaControl=new ArenaControl();
//        arenaControl.create(arena);
        arenaControl.deleteArenaById(2);
//        concertControl.updateConserta(concert);
//        AddressControl addressControl=new AddressControl();
//        //addressControl.create( address);
//        addressControl.create(address);
//        System.out.println(addressControl.ListAddress());
//
//
//
//        System.out.println(customer);
//        session.close();
        }



}



